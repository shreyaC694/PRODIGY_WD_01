#  Responsive Product Card Landing Page
## [Watch it on youtube](https://youtu.be/ic2k1bXhju8)
### Responsive Product Card Landing Page

- Responsive Product Card Landing Page HTML CSS & JavaScript
- Contains color change animations.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
